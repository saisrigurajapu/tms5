package com.vir.service;

import java.util.List;

import com.vir.model.Training;

public interface TrainingService {
	Training findById(int tngid);
	List<Training> findAll();
	Training add(Training tng);
	Training update( Training tng);
	Training remove(Training tng);

}
