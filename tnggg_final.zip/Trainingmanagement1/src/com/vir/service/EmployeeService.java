package com.vir.service;

import java.util.List;

import com.vir.model.Employee;
import com.vir.model.Training;

public interface EmployeeService {
	Employee findById(int empid);
	List<Employee> findAll();
	Employee addEmployeeServ(Employee emp);
	Employee updateEmployeeServ( Employee emp);
	Employee removeEmployeeServ(Employee emp);
	List<Training> ViewTrainingList();
	int	RequestTraining(Training tng);
	boolean validateEmpUser(int userid, String password);
}