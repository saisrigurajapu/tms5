package com.vir.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.vir.dao.TrainingDao;
import com.vir.dao.TrainingDaoImpl;
import com.vir.model.Training;

public class TrainingServiceImpl implements TrainingService {
	Logger log=Logger.getRootLogger();
TrainingDao dao=new TrainingDaoImpl();
	@Override
	public Training findById(int tngid) {
		return dao.findById(tngid);
	}

	@Override
	public List<Training> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Training add(Training tng) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Training update(Training tng) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Training remove(Training tng) {
		// TODO Auto-generated method stub
		return null;
	}

}
