package com.vir.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.vir.dao.EmployeeDao;
import com.vir.dao.EmployeeDaoImpl;
import com.vir.model.Employee;
import com.vir.model.Training;

//YAS#
public class EmployeeServiceImpl implements EmployeeService {
	Logger log = Logger.getRootLogger();
	Connection connection = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	private Connection getConnection() throws SQLException {
		Connection conn;
		conn = com.trainingmg.db.JdbcOracle.getInstance().getConnection();
		return conn;
	}

	EmployeeDao empser = new EmployeeDaoImpl();

	@Override
	public Employee findById(int empid) {
		return empser.findById(empid);
	}

	@Override
	public List<Employee> findAll() {

		return empser.findAll();
	}

	@Override
	public Employee addEmployeeServ(Employee emp) {
		return empser.addEmployee(emp);
	}

	@Override
	public Employee updateEmployeeServ(Employee emp) {
		return empser.updateEmployee(emp);
	}

	@Override
	public Employee removeEmployeeServ(Employee emp) {
		return empser.removeEmployee(emp.getEmpId());
	}

	@Override
	public boolean validateEmpUser(int userid, String password) {
		boolean status = false;
		EmployeeDao empDao = new EmployeeDaoImpl();
		Employee e = empDao.findById(userid);
		if (userid == e.getEmpId() && password.equals(e.getPassCode())) {
			status = true;
		} else {
			status = false;
		}
		return status;
	}



//	@Override
	public List<Training> ViewTrainingList()  {
		// TODO Auto-generated method stub
		List<Training> list = null;
		Training training = null;
		try {
			training = new Training();
			connection = getConnection();
			String query = "select tngtopic from training";
			ps = connection.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				training.setTngId(rs.getInt(1));
				list.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int RequestTraining(Training tng) {
		// TODO Auto-generated method stub
		return 0;
	}
	/*	public int validateAdminUser(Employee emp) {
	int user = emp.getEmpId();
	String pass = emp.getPassCode();
	String empType = emp.getEmpType();
	// log.trace("request for validation of " + emp);
	int status = 0;
	try {
		connection = getConnection();
		String query = "select * from employee where empid=? and passcode=? and emptype=?";
		ps = connection.prepareStatement(query);
		ps.setInt(1, user);
		ps.setString(2, pass);
		ps.setString(3, empType);
		ResultSet rs = ps.executeQuery();
		boolean gotResult = rs.next();
		if (gotResult)
			return 2;
		else
			return 0;
	} catch (SQLException e) {
		log.trace(e);
		return status;
	} catch (NullPointerException e) {
		log.trace(e);
		return status;
	}
}

public int validatePmUser(Employee emp) {
	int user = emp.getEmpId();
	String pass = emp.getPassCode();
	String empType = emp.getEmpType();
	log.trace("request for validation of  " + emp);
	int status = 0;
	try {
		connection = getConnection();
		String query = "select * from employee where empid=? and passcode=? and emptype=?";
		ps = connection.prepareStatement(query);
		ps.setInt(1, user);
		ps.setString(2, pass);
		ps.setString(3, empType);
		ResultSet rs = ps.executeQuery();
		boolean gotResult = rs.next();
		if (gotResult)
			return 3;
		else
			return 0;
	} catch (SQLException e) {
		log.trace(e);
		return status;
	} catch (NullPointerException e) {
		log.trace(e);
		return status;
	}
}*/
}