package com.vir.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vir.service.EmployeeService;
import com.vir.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmpTrainingList
 */
@WebServlet("/EmpTrainingList")
public class EmpTrainingList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpTrainingList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @param <Training>
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGET(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeService empServices=new EmployeeServiceImpl();
	
	
		 List<com.vir.model.Training> trainingList = empServices.ViewTrainingList(); 
		System.out.println("employee list got : " + trainingList + " with size " + trainingList.size());
		request.setAttribute("tlist", trainingList);
		request.getRequestDispatcher("/EmployeeLogin.jsp").forward(request, response);
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		doGet(request, response);
	}

}
