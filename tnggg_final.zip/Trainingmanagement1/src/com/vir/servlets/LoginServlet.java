package com.vir.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.vir.model.Employee;
import com.vir.service.EmployeeService;
import com.vir.service.EmployeeServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getRootLogger();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		boolean status= false;
		int userid=Integer.parseInt(request.getParameter("userid"));
		String password=request.getParameter("passcode");
		String empType=request.getParameter("empType");
		log.trace("request for " + userid+" "+empType + " " + password);
		EmployeeService empServices=new EmployeeServiceImpl();
		status=empServices.validateEmpUser(userid,password);
		/*else if(empType.equals("TAdmin"))
			status=eimpl.validateAdminUser(emp);
		else if(empType.equals("Project Manager"))
		status=eimpl.validatePmUser(emp);*/
		
		log.trace("status =" + status);
		String username = empServices.findById(userid).getEmpName();
		request.setAttribute("username", username);
		
		if(status)
		{
			String usertype = empServices.findById(userid).getEmpType();
			
			pw.print(userid);
			HttpSession session=request.getSession();
			session.setAttribute("userid", userid);
			
			String jspPageName = "";
			if(usertype.equals("Employee"))
				jspPageName = "/EmployeeLogin.jsp";
			else if(usertype.equals("TAdmin"))
				jspPageName = "AdminLogin.jsp";
			else if (usertype.equals("Project Manager"))
				jspPageName = "PmLogin.jsp";
			log.trace("jsppage to go:" + jspPageName);
			request.getRequestDispatcher(jspPageName).forward(request, response);
		}
	
		else
		{
			request.setAttribute("errorMessage", "Wrong user id or passcode");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}

		pw.close();

	}

}
