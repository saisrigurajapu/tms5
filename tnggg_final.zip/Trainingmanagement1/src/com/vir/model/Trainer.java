package com.vir.model;
public class Trainer {
private int trId;
private String trName,trEmpId;
public Trainer(int trId, String trName, String trEmpId) {
	super();
	this.trId = trId;
	this.trName = trName;
	this.trEmpId = trEmpId;
}
public int getTrId() {
	return trId;
}
public void setTrId(int trId) {
	this.trId = trId;
}
public String getTrName() {
	return trName;
}
public void setTrName(String trName) {
	this.trName = trName;
}
public String getTrEmpId() {
	return trEmpId;
}
public void setTrEmpId(String trEmpId) {
	this.trEmpId = trEmpId;
}

}
