package com.vir.model;

public class Training {
private int tngId,tngPropBy,trId;
private String tngTopic,tngSdate,tngEdate,tngVenue,appStatus;
public Training(int tngId, int tngPropBy, int trainerId, String tngTopic, String tngSdate, String tngEdate,
		String tngVenue, String appStatus) {
	super();
	this.tngId = tngId;
	this.tngPropBy = tngPropBy;
	this.trId = trainerId;
	this.tngTopic = tngTopic;
	this.tngSdate = tngSdate;
	this.tngEdate = tngEdate;
	this.tngVenue = tngVenue;
	this.appStatus = appStatus;
}
public int getTngId() {
	return tngId;
}
public void setTngId(int tngId) {
	this.tngId = tngId;
}
public int getTngPropBy() {
	return tngPropBy;
}
public void setTngPropBy(int tngPropBy) {
	this.tngPropBy = tngPropBy;
}
public int getTrainerId() {
	return trId;
}
public void setTrainerId(int trainerId) {
	this.trId = trainerId;
}
public Training() {
	super();
	// TODO Auto-generated constructor stub
}
public String getTngTopic() {
	return tngTopic;
}
public void setTngTopic(String tngTopic) {
	this.tngTopic = tngTopic;
}
public String getTngSdate() {
	return tngSdate;
}
public void setTngSdate(String tngSdate) {
	this.tngSdate = tngSdate;
}
public String getTngEdate() {
	return tngEdate;
}
public void setTngEdate(String tngEdate) {
	this.tngEdate = tngEdate;
}
public String getTngVenue() {
	return tngVenue;
}
public void setTngVenue(String tngVenue) {
	this.tngVenue = tngVenue;
}
public String getAppStatus() {
	return appStatus;
}
public void setAppStatus(String appStatus) {
	this.appStatus = appStatus;
}



}
