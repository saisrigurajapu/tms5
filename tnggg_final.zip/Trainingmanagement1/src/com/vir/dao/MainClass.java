package com.vir.dao;

import com.vir.model.Employee;

public class MainClass {

	public static void main(String[] args) {
		EmployeeDaoImpl ev = new EmployeeDaoImpl();
		Employee emp = new Employee();
		
		 emp.setEmpId(140); emp.setEmpName("sai"); emp.setPmId(105);
		  emp.setEmpType("Employee"); emp.setPassCode("Yash@123");
		  emp.setEmpEmail("yash@gmail.com");
		 
		  ev.addEmployee(emp);
		 	 
		/*emp.setEmpName("Yasin");
		emp.setPmId(106);

		emp.setPassCode("Yash@12345");
		emp.setEmpType("Employee");
		emp.setEmpEmail("Yashin@123");
		*/
		
		
		//ev.findAll();
		
	}

}
