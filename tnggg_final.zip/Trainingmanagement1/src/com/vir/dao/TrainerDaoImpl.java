package com.vir.dao;

import java.util.List;

import org.apache.log4j.Logger;

import com.vir.model.Trainer;

public class TrainerDaoImpl  implements TrainerDao{
	Logger log=Logger.getRootLogger();
	@Override
	public Trainer findById(int trid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Trainer> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainer add(Trainer tr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainer update(Trainer tr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainer remove(Trainer tr) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
