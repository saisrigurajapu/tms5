package com.vir.dao;

import java.util.List;

import com.vir.model.Trainer;

public interface TrainerDao {
	Trainer findById(int trid);
	List<Trainer> findAll();
	Trainer add(Trainer tr);
	Trainer update( Trainer tr);
	Trainer remove(Trainer tr);

}
